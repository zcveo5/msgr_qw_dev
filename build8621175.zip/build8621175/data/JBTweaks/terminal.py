import tkinter as tk

def execute(event):
    def _exec(source):
        code = """
def pp(*args, **kwargs):
    try:
        output.configure(state='normal')
        output.insert('end', f'{args[0]} | {args[1::]} {kwargs}')
        output.insert('end', '''
''')
        output.update()
        output.configure(state='disabled')
    except TclError:
        pass
print = pp\n""" + source

        exec(code, globals(), locals())

    cmd = event.widget.get().split()
    if cmd[0] == '$local':
        _exec(' '.join(cmd[1::]))
    elif cmd[0] == '$file':
        _exec(open(f'{cmd[1]}', 'r').read())
    

terminal = tk.Tk()
output = tk.Text(terminal)
output.pack()
output.configure(state='disabled')
entry = tk.Entry(terminal, width=50)
entry.pack()
entry.bind('<Return>', execute)

if __name__ == '__main__':
    terminal.mainloop()
else:
    main.tk_thread(terminal.update, 100)