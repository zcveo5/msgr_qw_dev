import json
import os.path
import subprocess
import sys
import tkinter
from tkinter.messagebox import showinfo
from data.lib import ui


class ModWin(ui.Win):
    def __init__(self, **kwargs):
        self.__mainloop = False
        super().__init__(**kwargs)
        self.title()
        self.his['load_lbl'] = tkinter.Label(justify='left')
        self.his['load_lbl'].place(x=0, y=0)
        def _wrapper():
            temp = sys.stdout.read().split('\n')
            if len(temp) > 24:
                temp = temp[len(temp) - 24::]
            try:
                self.his['load_lbl']['text'] = '\n'.join(temp)
            except KeyError:
                print('Loaded!')
                return -1
        self.tk_thread(_wrapper, 50)
    def mainloop(self, n = 0):
        if 'READY' in sys.stdout.read():
            print('$JB Final mainloop')
            if not os.path.exists('./data/JBTweaks'):
                print('$JB Running setup...')
                setup()
            super().mainloop(n)
        else:
            print('$JB Skipping non-final mainloop')
    def title(self, *args):
        super().title('$ JailBreak $')


def setup():
    showinfo('$JB', 'Welcome to Jailbreak!\n\nTweaks should be installed in data/JBTweaks\nTo configure Tweaks run data/JBTweaks/configure.py\n\nEnjoy!')
    os.makedirs('./data/JBTweaks', exist_ok=True)
    with open('./data/JBTweaks/configure.py', 'w') as fl:
        fl.write(...)


if __name__ == '__main__':
    print('$JB Launcher Mode')
    if '--debug' not in sys.argv:
        open('./jaillib.py', 'r').read()
        os.environ['__LOW_LAUNCHER'] = os.path.abspath('launcher.pyw')
        subprocess.run([sys.executable, 'loader.py', 'RunBeforeWin$=%from jailbreak import * ; Win = ModWin', "BootUpAction$=%exec(open('./jaillib.py', 'r').read())"])
    else:
        while True:
            exec(input('>>>'))